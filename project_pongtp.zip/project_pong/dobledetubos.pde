class DuplaDeTubos {
  Cuadrado sup, inf;

  DuplaDeTubos(PVector pos_m) {
    float gapSize = 160; 
    float altoTubo = 300; 
    

    float yArriba = pos_m.y - gapSize/2 - altoTubo;
    float yAbajo  = pos_m.y + gapSize/2 + altoTubo;

    sup = new Cuadrado(pos_m.x, yArriba, 15, altoTubo);
    inf = new Cuadrado(pos_m.x, yAbajo, 15, altoTubo);
  }

  void mover() {
    sup.mover();
    inf.mover();
  }

  void mostrar() {
    sup.mostrar();
    inf.mostrar();
  }
}
