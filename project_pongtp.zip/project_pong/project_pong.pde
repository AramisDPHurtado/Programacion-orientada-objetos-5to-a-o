ArrayList<DuplaDeTubos> tubos;
Circulo bird;
float ultimaPar = 0;
PVector G = new PVector(0, 0.5);
int estado = 0;
Circulo p;
int sep = 30;
Cuadrado j1, j2;

void setup() {
  size(700, 700);
  p = new Circulo(); 
  tubos = new ArrayList<DuplaDeTubos>();
  bird = new Circulo(200, height/2);
  j1 = new Cuadrado(sep);
  j2 = new Cuadrado(width-sep);
}

void agregarTubos() {
  float tActual = millis();
  float dT = tActual - ultimaPar;
  if (dT > 1500) {
    PVector posicion = new PVector(width, height/2);
    tubos.add(new DuplaDeTubos(posicion));
    ultimaPar = tActual;
  }
}

void borrarTubos() {
  for (int i = tubos.size() - 1; i >= 0; i--) {
    if (tubos.get(i).sup.pos.x < 0) {
      tubos.remove(i);
    }
  }
}

void draw() {
  background(0);
  
  if (estado == 0) {
    textSize(20);
    fill(255);
    textAlign(CENTER, CENTER);
    text("Presiona 1 para el pong y 2 para el flappy", width/2, height/2);

    if (is1) estado = 1;
    if (is2) estado = 2;
  }
  
  if (estado == 1) {
    p.mover();
    p.contener();
    j1.moverpong(is_w, is_s);
    j2.moverpong(is_o, is_l);
    
    // Rebote horizontal estilo Pong
    if (j1.chocaCon(p.pos, p.r)) {
      p.rebotarPong();
      p.pos.x = j1.pos.x + j1.tx + p.r; // Ajuste para evitar fricción pegada
    }

    if (j2.chocaCon(p.pos, p.r)) {
      p.rebotarPong();
      p.pos.x = j2.pos.x - j2.tx - p.r; // Ajuste para evitar fricción pegada
    }

    // Reinicio al salir de pantalla
    if (p.pos.x < 0 || p.pos.x > width) {
      p = new Circulo();
    }
    
    otroBackground();
    p.mostrar();
    j1.mostrar();
    j2.mostrar();
  }

  if (estado == 2) {
    agregarTubos();
    bird.addFuerza(G);
    bird.saltfla(is_j);
    if (is_j) is_j = false;
    
    // Muerte por caerse de la pantalla en Flappy Bird
    if (bird.pos.y > height || bird.pos.y < 0) {
      estado = 3;
    }

    borrarTubos();
    
    for (DuplaDeTubos t : tubos) {
      t.mover();
      t.mostrar();
      
      if (t.sup.chocaCon(bird.pos, bird.r) || t.inf.chocaCon(bird.pos, bird.r)) {
        estado = 3;
      }
    }
    
    bird.mostrar();
  }

  if (estado == 3) {
    fill(255, 0, 0);
    textSize(30);
    textAlign(CENTER, CENTER);
    text("You Died", width/2, height/2);
  }
}

void otroBackground() {
  fill(0, 30);
  rectMode(CORNER);
  rect(0, 0, width, height);
}
