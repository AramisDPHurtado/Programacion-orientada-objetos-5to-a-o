boolean is_j = false;
boolean is1 = false;
boolean is2 = false;
boolean is_w = false, is_s = false, is_o = false, is_l = false; 

void keyPressed() {
  if (key == 'j' || key == 'J') {
    is_j = true;
  }
  if (key == '1') {
    is1 = true;
  }
  if (key == '2') {
    is2 = true;
  }
  if (key == 'w' || key == 'W') is_w = true; 
  if (key == 's' || key == 'S') is_s = true; 
  if (key == 'o' || key == 'O') is_o = true; 
  if (key == 'l' || key == 'L') is_l = true; 
}

void keyReleased() {
  if (key == 'j' || key == 'J') {
    is_j = false;
  }
  if (key == '1') {
    is1 = false;
  }
  if (key == '2') {
    is2 = false;
  }
  if (key == 'w' || key == 'W') is_w = false; 
  if (key == 's' || key == 'S') is_s = false; 
  if (key == 'o' || key == 'O') is_o = false; 
  if (key == 'l' || key == 'L') is_l = false; 
}
