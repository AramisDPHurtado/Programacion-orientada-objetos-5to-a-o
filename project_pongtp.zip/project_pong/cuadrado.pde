class Cuadrado {
  PVector pos;
  float tx = 10, ty = 40; 
  int puntaje = 0;
  float vel = 3;

  Cuadrado(float x, float y, float ancho, float alto) {
    pos = new PVector(x, y);
    tx = ancho;
    ty = alto;
  }


  Cuadrado(float columna) {
    pos = new PVector(columna, height/2);
    tx = 10;
    ty = 40;
  }

  void mostrar() {
    rectMode(RADIUS);
    rect(pos.x, pos.y, tx, ty);
  }

  void mover() {
    pos.x -= vel;
  }

  void moverpong(boolean up, boolean down) {
    if (up) pos.y -= 7;
    if (down) pos.y += 7;
    pos.y = constrain(pos.y, ty, height - ty);
  }

  boolean chocaCon(PVector otraPos, float r) {
    PVector PMC = new PVector(0, 0);

    if (otraPos.x < pos.x-tx) PMC.x = pos.x-tx;
    else if (otraPos.x > pos.x+tx) PMC.x = pos.x+tx;
    else PMC.x = otraPos.x;

    if (otraPos.y < pos.y-ty) PMC.y = pos.y-ty;
    else if (otraPos.y > pos.y+ty) PMC.y = pos.y+ty;
    else PMC.y = otraPos.y;

    return (PMC.dist(otraPos) < r);
  }
}
