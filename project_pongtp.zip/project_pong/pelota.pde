class Circulo {
  PVector acel = new PVector(0, 0);
  PVector pos;
  PVector vel;
  float r = 15;
  color c = color(255);

  Circulo(float x, float y) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
  }

  Circulo() {
    pos = new PVector(width/2, height/2);
    vel = new PVector(random(10) < 5 ? 5 : -5, random(-3, 3));
  }

  void rebotarPong() {
    vel.x *= -1; // Invierte sentido horizontal al chocar con las paletas
  }

  void addFuerza(PVector f) {
    acel.add(f);
  }

  void contener() {
    if (pos.y - r < 0 || pos.y + r > height) {
      vel.y *= -1;
    }
  }

  void mover() {
    vel.add(acel);
    acel.mult(0);
    pos.add(vel);
  }

  void saltfla(boolean jump) {
    if (jump) vel.y = -7;
    vel.add(acel);
    vel.limit(30);
    pos.add(vel);
    acel.mult(0);
  }

  void mostrar() {
    fill(c);
    circle(pos.x, pos.y, r * 2);
  }
}
